package sait.mms.manager;
// displayMenu: Displays the main menu to the user.
// addMovie: Prompts the user to add a movie.
// generateMovieListInYear: Displays movies released in a specific year.
// generateRandomMovieList: Generates and displays a random selection of movies.
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;


import sait.mms.problemdomain.Movie;


public class MovieManager {
	
	private ArrayList<Movie> movies = new ArrayList<>();
	
	public int displayMenu(Scanner sc) {
		System.out.println("Movie Management system\n");
		System.out.println("1     Add New Movie and Save\n");
		System.out.println("2     Generate List of Movies Released in a Year\n");
		System.out.println("3     Generate List of Random Movies\n");
		System.out.println("4     Exit\n");
		System.out.print("Enter an option: ");

        return sc.nextInt();
    }
	
    public void loadMovieList() {
        movies.clear();

        try (BufferedReader br = new BufferedReader(new FileReader("res/movies.txt"))) {
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s*,\\s*"); 
                if (parts.length < 3) continue;

                int duration = Integer.parseInt(parts[0]);
                String title = parts[1];
                int year = Integer.parseInt(parts[2]);

                movies.add(new Movie(duration, title, year));
            }

        } catch (IOException e) {
            System.out.println("Error loading movies file.");
        }
    }

	
	public void addMovie(Scanner sc) {
		System.out.println("\nEnter duration: ");
		int duration = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter movie title: ");
		String title = sc.nextLine();
		
		System.out.println("Enter year: ");
		int year = sc.nextInt();
		
		if (duration <= 0 || year <= 0 || title.trim().isEmpty()) {
            System.out.println("\nInvalid input!\n");
            return;
        }
		
		movies.add(new Movie(duration, title, year));
	
		System.out.println("Saving movie...");
		System.out.println("Added movie to the data files.\n");
		
		
	}
	// Displays the mvoies in specific years
	public void generateMovieListInYear(Scanner sc) {
	    System.out.print("Enter year: ");
	    int year = sc.nextInt();

	    System.out.println("\nMovie List");
	    System.out.println("Duration\tYear\tTitle");

	    int totalDuration = 0;

	    for (Movie movie : movies) {
	        if (movie.getYear() == year) {

	            System.out.println(
	                movie.getDuration() + "\t\t" +
	                movie.getYear() + "\t" +
	                movie.getTitle());

	            totalDuration += movie.getDuration();
	        }
	    }

	    System.out.println("\nTotal duration: " + totalDuration + " minutes\n");
	}
            
	public void generateRandomMovieList(Scanner sc) {
        System.out.print("\nEnter number of movies: ");
        int count = sc.nextInt();

        if (count <= 0 || movies.isEmpty()) {
            System.out.println("\nInvalid number of movies.\n");
            return;
        }

        System.out.println("\nMovie List");
        System.out.println("Duration\tYear\tTitle");

        Random rand = new Random();
        int totalDuration = 0;
        for (int i = 0; i < count; i++) {
            int randIndex = rand.nextInt(movies.size());
            Movie movie = movies.get(randIndex);

            System.out.println(movie.getDuration() + "\t\t" +
                               movie.getYear() + "\t" +
                               movie.getTitle());

            totalDuration += movie.getDuration();
        }

        System.out.println("\nTotal duration: " + totalDuration + " minutes\n");
    }
	public void saveMovieListToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("res/movies.txt"))) {
            for (Movie movie : movies) {
                pw.println(movie.getDuration() + "," + movie.getTitle() + "," + movie.getYear());
            }

            System.out.println("Saving movies...");
            System.out.println("Added movie to the data file.");

        } catch (IOException e) {
            System.out.println("Error saving movies file.");
        }
    }
}
	